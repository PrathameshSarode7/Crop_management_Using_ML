# E-Commerce Microservices — Complete System
# Eureka + API Gateway + 4 Business Services

## Complete Project Structure

```
ecommerce-final/
├── eureka-server/         → Port 8761  (Service Registry)
├── api-gateway/           → Port 8080  (Single Entry Point) ← NEW
├── item-service/          → Port 8081  (DB: item_db)
├── inventory-service/     → Port 8082  (DB: inventory_db)
├── notification-service/  → Port 8083  (DB: notification_db)
└── audit-service/         → Port 8084  (DB: audit_db)
```

---

## What is API Gateway?

Before API Gateway — clients need to know 4 different ports:
  http://localhost:8081/api/items
  http://localhost:8082/api/inventory
  http://localhost:8083/api/notifications
  http://localhost:8084/api/audit-logs

After API Gateway — everything goes through ONE port 8080:
  http://localhost:8080/api/items         → routed to item-service (8081)
  http://localhost:8080/api/inventory     → routed to inventory-service (8082)
  http://localhost:8080/api/notifications → routed to notification-service (8083)
  http://localhost:8080/api/audit-logs    → routed to audit-service (8084)

The client only talks to port 8080. Gateway handles the rest.

---

## Step-by-Step Setup in Spring Tool Suite

### Step 1 — Create MySQL Databases

Open MySQL and run:
  CREATE DATABASE item_db;
  CREATE DATABASE inventory_db;
  CREATE DATABASE notification_db;
  CREATE DATABASE audit_db;

### Step 2 — Update DB Password

In each of the 4 services open application.properties and change:
  spring.datasource.password=root
to your MySQL password.

### Step 3 — Import ALL 6 Projects into STS

File -> Import -> Maven -> Existing Maven Projects
Browse to ecommerce-final folder
Select ALL 6 projects
Click Finish
Wait for Maven to download all dependencies (first time 3-5 minutes)

### Step 4 — VERY IMPORTANT: Start Order

START IN THIS EXACT ORDER:

1. eureka-server     ← FIRST. Wait until console shows "Started EurekaServerApplication"
2. api-gateway       ← SECOND. Wait until it registers with Eureka
3. item-service      ← Then these 4 in any order
4. inventory-service
5. notification-service
6. audit-service

### Step 5 — Verify Everything is Working

Check Eureka Dashboard:
  Open: http://localhost:8761
  You should see ALL 5 services registered:
    - API-GATEWAY
    - ITEM-SERVICE
    - INVENTORY-SERVICE
    - NOTIFICATION-SERVICE
    - AUDIT-SERVICE

### Step 6 — Get JWT Token

Go to https://jwt.io
Payload: {"sub": "admin"}
Secret:  ecommerce-item-service-secret-key-for-jwt-auth-2025
Uncheck "secret base64 encoded"
Copy the token

### Step 7 — Test APIs Through the Gateway (Port 8080)

NOW USE PORT 8080 FOR EVERYTHING:

Item Service via Gateway:
  POST   http://localhost:8080/api/items
  GET    http://localhost:8080/api/items
  GET    http://localhost:8080/api/items/1
  PUT    http://localhost:8080/api/items/1
  DELETE http://localhost:8080/api/items/1

Inventory Service via Gateway:
  POST   http://localhost:8080/api/inventory
  GET    http://localhost:8080/api/inventory
  GET    http://localhost:8080/api/inventory/low-stock?threshold=10

Notification Service via Gateway:
  POST   http://localhost:8080/api/notifications
  GET    http://localhost:8080/api/notifications

Audit Service via Gateway:
  POST   http://localhost:8080/api/audit-logs
  GET    http://localhost:8080/api/audit-logs

Add Authorization header to every request:
  Authorization: Bearer YOUR_JWT_TOKEN

You can still use individual ports directly for Swagger:
  http://localhost:8081/swagger-ui.html  (Item Service Swagger)
  http://localhost:8082/swagger-ui.html  (Inventory Service Swagger)
  http://localhost:8083/swagger-ui.html  (Notification Service Swagger)
  http://localhost:8084/swagger-ui.html  (Audit Service Swagger)

---

## How Routing Works in Gateway

In application.yml the routes are defined like this:

  - id: item-service
    uri: lb://item-service      <- lb means Load Balanced via Eureka
    predicates:
      - Path=/api/items/**      <- if URL matches this pattern

When a request comes to gateway:
  1. Gateway checks the URL path
  2. Matches it against all route predicates
  3. Finds the matching route
  4. Looks up the service address from Eureka (lb:// means use Eureka)
  5. Forwards the request to that service
  6. Returns the response back to client

---

## What Each File Does in API Gateway

pom.xml
  spring-cloud-starter-gateway    -> makes this app a gateway
  spring-cloud-starter-netflix-eureka-client -> registers with Eureka

application.yml
  Defines all 4 routes with URL patterns
  Eureka connection settings
  CORS settings

ApiGatewayApplication.java
  Main class with @EnableDiscoveryClient

RequestLoggingFilter.java
  Runs on every request
  Logs the method, path, status, and response time in console

FallbackController.java
  Returns a friendly message if a service is down

---

## Ports Summary

| Service              | Port | Role                        |
|----------------------|------|-----------------------------|
| Eureka Server        | 8761 | Service Registry Dashboard  |
| API Gateway          | 8080 | Single Entry Point          |
| Item Service         | 8081 | Manages Products            |
| Inventory Service    | 8082 | Manages Stock               |
| Notification Service | 8083 | Manages Notifications       |
| Audit Service        | 8084 | Manages Audit Logs          |

---

## Common Issues and Fixes

| Problem | Fix |
|---------|-----|
| Gateway returns 503 Service Unavailable | The target service is not running. Start it. |
| Services not in Eureka | Start eureka-server first, then restart services |
| Gateway not routing | Check application.yml route paths match your API URLs |
| Maven errors on import | Right click -> Maven -> Update Project -> Force Update |
| Port 8080 already in use | Change server.port in api-gateway application.yml |
| 401 Unauthorized | Add Authorization: Bearer token in your request header |

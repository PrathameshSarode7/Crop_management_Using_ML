package com.ecommerce.apigateway.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/fallback")
public class FallbackController {

    @GetMapping("/item-service")
    public ResponseEntity<Map<String, String>> itemServiceFallback() {
        return buildFallbackResponse("Item Service");
    }

    @GetMapping("/inventory-service")
    public ResponseEntity<Map<String, String>> inventoryServiceFallback() {
        return buildFallbackResponse("Inventory Service");
    }

    @GetMapping("/notification-service")
    public ResponseEntity<Map<String, String>> notificationServiceFallback() {
        return buildFallbackResponse("Notification Service");
    }

    @GetMapping("/audit-service")
    public ResponseEntity<Map<String, String>> auditServiceFallback() {
        return buildFallbackResponse("Audit Service");
    }

    private ResponseEntity<Map<String, String>> buildFallbackResponse(String serviceName) {
        Map<String, String> response = new HashMap<>();
        response.put("success", "false");
        response.put("message", serviceName + " is currently unavailable. Please try again later.");
        response.put("status", "SERVICE_DOWN");
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
    }
}

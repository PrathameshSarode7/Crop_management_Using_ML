package com.ecommerce.apigateway.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Component
public class RequestLoggingFilter implements GlobalFilter, Ordered {

    private static final Logger log = LoggerFactory.getLogger(RequestLoggingFilter.class);

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        ServerHttpRequest request = exchange.getRequest();

        // Log every request that comes through the gateway
        log.info("====== API GATEWAY REQUEST ======");
        log.info("Method  : {}", request.getMethod());
        log.info("Path    : {}", request.getURI().getPath());
        log.info("From    : {}", request.getRemoteAddress());
        log.info("=================================");

        // Record start time
        long startTime = System.currentTimeMillis();

        return chain.filter(exchange).then(Mono.fromRunnable(() -> {
            long duration = System.currentTimeMillis() - startTime;
            log.info("====== API GATEWAY RESPONSE ======");
            log.info("Path     : {}", request.getURI().getPath());
            log.info("Status   : {}", exchange.getResponse().getStatusCode());
            log.info("Duration : {} ms", duration);
            log.info("==================================");
        }));
    }

    @Override
    public int getOrder() {
        return -1; // Run this filter first before everything else
    }
}

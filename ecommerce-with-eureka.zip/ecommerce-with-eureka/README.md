# E-Commerce Microservices with Eureka Service Discovery

## Project Structure

```
ecommerce-with-eureka/
├── eureka-server/         → Port 8761  (Service Registry Dashboard)
├── item-service/          → Port 8081  (DB: item_db)
├── inventory-service/     → Port 8082  (DB: inventory_db)
├── notification-service/  → Port 8083  (DB: notification_db)
└── audit-service/         → Port 8084  (DB: audit_db)
```

---

## What is Eureka?

Eureka is a Service Discovery Server from Netflix.
- All 4 microservices register themselves with Eureka when they start
- Eureka keeps a live list of all running services
- You can see all registered services at: http://localhost:8761
- If a service goes down, Eureka removes it from the list automatically

---

## Step-by-Step Setup in Spring Tool Suite

### Step 1 — Create MySQL Databases

```sql
CREATE DATABASE item_db;
CREATE DATABASE inventory_db;
CREATE DATABASE notification_db;
CREATE DATABASE audit_db;
```

### Step 2 — Update DB Password in Each Service

In each of the 4 services open:
src/main/resources/application.properties

Change:
```
spring.datasource.password=root
```
To your actual MySQL password.

### Step 3 — Import ALL 5 Projects into STS

File -> Import -> Maven -> Existing Maven Projects
Browse to ecommerce-with-eureka folder
Select ALL 5 projects (eureka-server + 4 services)
Click Finish
Wait for Maven to download dependencies

### Step 4 — VERY IMPORTANT: Start Order

YOU MUST START EUREKA SERVER FIRST.
If you start other services before Eureka, they cannot register.

Start in this exact order:
1. eureka-server           (wait 30 seconds for it to fully start)
2. item-service
3. inventory-service
4. notification-service
5. audit-service

### Step 5 — Verify Eureka Dashboard

Open browser: http://localhost:8761

You will see the Eureka dashboard.
Under "Instances currently registered with Eureka" you should see:
- ITEM-SERVICE
- INVENTORY-SERVICE
- NOTIFICATION-SERVICE
- AUDIT-SERVICE

If all 4 appear, everything is working correctly.

### Step 6 — Get JWT Token

Go to https://jwt.io
Set payload: {"sub": "admin"}
Set secret: ecommerce-item-service-secret-key-for-jwt-auth-2025
Uncheck "secret base64 encoded"
Copy the token from left side

### Step 7 — Test APIs via Swagger

Item Service:         http://localhost:8081/swagger-ui.html
Inventory Service:    http://localhost:8082/swagger-ui.html
Notification Service: http://localhost:8083/swagger-ui.html
Audit Service:        http://localhost:8084/swagger-ui.html

Click Authorize -> paste: Bearer YOUR_TOKEN -> test APIs

---

## What Changed from Previous Version

Only 3 things changed in each microservice:

1. pom.xml
   Added spring-cloud-starter-netflix-eureka-client dependency
   Added spring-cloud-dependencies in dependencyManagement
   Added spring-cloud.version property

2. application.properties
   Added spring.application.name
   Added 4 eureka config lines

3. Main Application class
   Added @EnableDiscoveryClient annotation

That is all. No business logic changed. All APIs work exactly the same.

---

## Eureka Config Explained (in application.properties)

spring.application.name=item-service
  The name this service shows up as in Eureka dashboard

eureka.client.service-url.defaultZone=http://localhost:8761/eureka/
  The address of the Eureka server

eureka.client.register-with-eureka=true
  This service registers itself with Eureka on startup

eureka.client.fetch-registry=true
  This service downloads the list of all other services from Eureka

eureka.instance.prefer-ip-address=true
  Register using IP address instead of machine hostname

---

## Ports Summary

| Service              | Port | Database        |
|----------------------|------|-----------------|
| Eureka Server        | 8761 | No database     |
| Item Service         | 8081 | item_db         |
| Inventory Service    | 8082 | inventory_db    |
| Notification Service | 8083 | notification_db |
| Audit Service        | 8084 | audit_db        |

---

## Common Issues and Fixes

| Problem | Fix |
|---------|-----|
| Services not showing in Eureka | Start eureka-server FIRST then restart services |
| Eureka dashboard not opening | Check eureka-server is running on port 8761 |
| Service shows DOWN in Eureka | Restart that specific service |
| Maven dependency errors | Right click project -> Maven -> Update Project |
| Port already in use | Change port in application.properties |
| 401 Unauthorized on API | Generate JWT token and add Bearer token in Swagger Authorize |

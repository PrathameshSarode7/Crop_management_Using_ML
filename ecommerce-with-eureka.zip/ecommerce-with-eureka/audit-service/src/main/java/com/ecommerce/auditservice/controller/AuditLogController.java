package com.ecommerce.auditservice.controller;

import com.ecommerce.auditservice.dto.ApiResponse;
import com.ecommerce.auditservice.dto.AuditLogDTO;
import com.ecommerce.auditservice.service.AuditLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
@RequiredArgsConstructor
@Tag(name = "Audit & Logging Service", description = "APIs for audit log management")
public class AuditLogController {

    private final AuditLogService auditLogService;

    @PostMapping
    @Operation(summary = "Log a new event")
    public ResponseEntity<ApiResponse<AuditLogDTO>> logEvent(@Valid @RequestBody AuditLogDTO dto) {
        AuditLogDTO created = auditLogService.logEvent(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Audit log created successfully", created));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Retrieve audit log by ID")
    public ResponseEntity<ApiResponse<AuditLogDTO>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Audit log retrieved", auditLogService.getLogById(id)));
    }

    @GetMapping
    @Operation(summary = "Retrieve all audit logs")
    public ResponseEntity<ApiResponse<List<AuditLogDTO>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("All audit logs retrieved", auditLogService.getAllLogs()));
    }

    @GetMapping("/service/{serviceName}")
    @Operation(summary = "Get logs by service name")
    public ResponseEntity<ApiResponse<List<AuditLogDTO>>> getByService(@PathVariable String serviceName) {
        return ResponseEntity.ok(ApiResponse.success("Logs retrieved", auditLogService.getLogsByService(serviceName)));
    }

    @GetMapping("/operation/{operation}")
    @Operation(summary = "Get logs by operation type")
    public ResponseEntity<ApiResponse<List<AuditLogDTO>>> getByOperation(@PathVariable String operation) {
        return ResponseEntity.ok(ApiResponse.success("Logs retrieved", auditLogService.getLogsByOperation(operation)));
    }

    @GetMapping("/record/{recordId}")
    @Operation(summary = "Get logs by record ID")
    public ResponseEntity<ApiResponse<List<AuditLogDTO>>> getByRecordId(@PathVariable Long recordId) {
        return ResponseEntity.ok(ApiResponse.success("Logs retrieved", auditLogService.getLogsByRecordId(recordId)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update log information")
    public ResponseEntity<ApiResponse<AuditLogDTO>> updateLog(@PathVariable Long id,
                                                               @Valid @RequestBody AuditLogDTO dto) {
        return ResponseEntity.ok(ApiResponse.success("Audit log updated", auditLogService.updateLog(id, dto)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Remove a log entry")
    public ResponseEntity<ApiResponse<Void>> deleteLog(@PathVariable Long id) {
        auditLogService.deleteLog(id);
        return ResponseEntity.ok(ApiResponse.success("Audit log deleted", null));
    }
}

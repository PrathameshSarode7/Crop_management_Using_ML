package com.ecommerce.auditservice.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLogDTO {

    private Long id;

    @NotBlank(message = "Service name is required")
    @Size(max = 100)
    private String serviceName;

    @NotBlank(message = "Operation is required")
    @Size(max = 50)
    private String operation;

    @NotNull(message = "Record ID is required")
    private Long recordId;

    private LocalDateTime timestamp;

    private String details;
}

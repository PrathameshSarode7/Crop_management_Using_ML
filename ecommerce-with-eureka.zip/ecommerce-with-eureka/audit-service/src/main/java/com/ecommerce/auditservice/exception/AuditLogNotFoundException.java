package com.ecommerce.auditservice.exception;

public class AuditLogNotFoundException extends RuntimeException {
    public AuditLogNotFoundException(Long id) {
        super("Audit log not found with id: " + id);
    }
}

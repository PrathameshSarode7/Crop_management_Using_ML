package com.ecommerce.auditservice.repository;

import com.ecommerce.auditservice.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    List<AuditLog> findByServiceName(String serviceName);
    List<AuditLog> findByOperation(String operation);
    List<AuditLog> findByRecordId(Long recordId);
    List<AuditLog> findByTimestampBetween(LocalDateTime start, LocalDateTime end);
}

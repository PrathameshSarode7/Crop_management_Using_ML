package com.ecommerce.auditservice.service;

import com.ecommerce.auditservice.dto.AuditLogDTO;
import java.util.List;

public interface AuditLogService {
    AuditLogDTO logEvent(AuditLogDTO dto);
    AuditLogDTO getLogById(Long id);
    List<AuditLogDTO> getAllLogs();
    List<AuditLogDTO> getLogsByService(String serviceName);
    List<AuditLogDTO> getLogsByOperation(String operation);
    List<AuditLogDTO> getLogsByRecordId(Long recordId);
    AuditLogDTO updateLog(Long id, AuditLogDTO dto);
    void deleteLog(Long id);
}

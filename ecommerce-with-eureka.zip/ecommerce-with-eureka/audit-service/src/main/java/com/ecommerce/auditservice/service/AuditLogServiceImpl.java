package com.ecommerce.auditservice.service;

import com.ecommerce.auditservice.dto.AuditLogDTO;
import com.ecommerce.auditservice.exception.AuditLogNotFoundException;
import com.ecommerce.auditservice.model.AuditLog;
import com.ecommerce.auditservice.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository auditLogRepository;

    @Override
    public AuditLogDTO logEvent(AuditLogDTO dto) {
        log.info("Logging event: service={}, operation={}, recordId={}", dto.getServiceName(), dto.getOperation(), dto.getRecordId());
        AuditLog auditLog = AuditLog.builder()
                .serviceName(dto.getServiceName())
                .operation(dto.getOperation())
                .recordId(dto.getRecordId())
                .timestamp(LocalDateTime.now())
                .details(dto.getDetails())
                .build();
        return toDTO(auditLogRepository.save(auditLog));
    }

    @Override
    @Transactional(readOnly = true)
    public AuditLogDTO getLogById(Long id) {
        return toDTO(auditLogRepository.findById(id)
                .orElseThrow(() -> new AuditLogNotFoundException(id)));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogDTO> getAllLogs() {
        return auditLogRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogDTO> getLogsByService(String serviceName) {
        return auditLogRepository.findByServiceName(serviceName).stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogDTO> getLogsByOperation(String operation) {
        return auditLogRepository.findByOperation(operation).stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogDTO> getLogsByRecordId(Long recordId) {
        return auditLogRepository.findByRecordId(recordId).stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    public AuditLogDTO updateLog(Long id, AuditLogDTO dto) {
        AuditLog auditLog = auditLogRepository.findById(id)
                .orElseThrow(() -> new AuditLogNotFoundException(id));
        auditLog.setServiceName(dto.getServiceName());
        auditLog.setOperation(dto.getOperation());
        auditLog.setRecordId(dto.getRecordId());
        auditLog.setDetails(dto.getDetails());
        return toDTO(auditLogRepository.save(auditLog));
    }

    @Override
    public void deleteLog(Long id) {
        if (!auditLogRepository.existsById(id)) {
            throw new AuditLogNotFoundException(id);
        }
        auditLogRepository.deleteById(id);
        log.info("Audit log deleted: {}", id);
    }

    private AuditLogDTO toDTO(AuditLog log) {
        return AuditLogDTO.builder()
                .id(log.getId())
                .serviceName(log.getServiceName())
                .operation(log.getOperation())
                .recordId(log.getRecordId())
                .timestamp(log.getTimestamp())
                .details(log.getDetails())
                .build();
    }
}

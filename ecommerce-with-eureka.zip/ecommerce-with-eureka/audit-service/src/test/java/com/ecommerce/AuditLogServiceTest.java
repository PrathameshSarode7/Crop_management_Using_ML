package com.ecommerce.auditservice;

import com.ecommerce.auditservice.dto.AuditLogDTO;
import com.ecommerce.auditservice.exception.AuditLogNotFoundException;
import com.ecommerce.auditservice.model.AuditLog;
import com.ecommerce.auditservice.repository.AuditLogRepository;
import com.ecommerce.auditservice.service.AuditLogServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuditLogServiceTest {

    @Mock
    private AuditLogRepository auditLogRepository;

    @InjectMocks
    private AuditLogServiceImpl auditLogService;

    private AuditLog sample;
    private AuditLogDTO sampleDTO;

    @BeforeEach
    void setUp() {
        sample = AuditLog.builder()
                .id(1L).serviceName("Item Service")
                .operation("DELETE").recordId(1005L)
                .timestamp(LocalDateTime.now())
                .details("Item deleted by admin").build();
        sampleDTO = AuditLogDTO.builder()
                .serviceName("Item Service").operation("DELETE")
                .recordId(1005L).details("Item deleted by admin").build();
    }

    @Test
    void logEvent_ShouldReturnSaved() {
        when(auditLogRepository.save(any())).thenReturn(sample);
        AuditLogDTO result = auditLogService.logEvent(sampleDTO);
        assertThat(result.getServiceName()).isEqualTo("Item Service");
        assertThat(result.getOperation()).isEqualTo("DELETE");
    }

    @Test
    void getLogById_WhenNotExists_ShouldThrow() {
        when(auditLogRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> auditLogService.getLogById(99L))
                .isInstanceOf(AuditLogNotFoundException.class);
    }

    @Test
    void deleteLog_ShouldDelete() {
        when(auditLogRepository.existsById(1L)).thenReturn(true);
        auditLogService.deleteLog(1L);
        verify(auditLogRepository).deleteById(1L);
    }

    @Test
    void getAllLogs_ShouldReturnList() {
        when(auditLogRepository.findAll()).thenReturn(List.of(sample));
        List<AuditLogDTO> result = auditLogService.getAllLogs();
        assertThat(result).hasSize(1);
    }
}

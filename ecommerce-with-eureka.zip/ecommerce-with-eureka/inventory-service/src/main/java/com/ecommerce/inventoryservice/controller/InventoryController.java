package com.ecommerce.inventoryservice.controller;

import com.ecommerce.inventoryservice.dto.ApiResponse;
import com.ecommerce.inventoryservice.dto.InventoryDTO;
import com.ecommerce.inventoryservice.service.InventoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
@Tag(name = "Inventory Service", description = "APIs for managing inventory")
public class InventoryController {

    private final InventoryService inventoryService;

    @PostMapping
    @Operation(summary = "Add inventory for an item")
    public ResponseEntity<ApiResponse<InventoryDTO>> addInventory(@Valid @RequestBody InventoryDTO dto) {
        InventoryDTO created = inventoryService.addInventory(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Inventory added successfully", created));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get inventory by ID")
    public ResponseEntity<ApiResponse<InventoryDTO>> getInventoryById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Inventory retrieved", inventoryService.getInventoryById(id)));
    }

    @GetMapping
    @Operation(summary = "Get all inventory records")
    public ResponseEntity<ApiResponse<List<InventoryDTO>>> getAllInventory() {
        return ResponseEntity.ok(ApiResponse.success("All inventory retrieved", inventoryService.getAllInventory()));
    }

    @GetMapping("/item/{itemId}")
    @Operation(summary = "Get inventory by item ID")
    public ResponseEntity<ApiResponse<List<InventoryDTO>>> getByItemId(@PathVariable Long itemId) {
        return ResponseEntity.ok(ApiResponse.success("Inventory for item retrieved", inventoryService.getInventoryByItemId(itemId)));
    }

    @GetMapping("/low-stock")
    @Operation(summary = "Get low stock items below threshold")
    public ResponseEntity<ApiResponse<List<InventoryDTO>>> getLowStock(
            @RequestParam(defaultValue = "10") Integer threshold) {
        return ResponseEntity.ok(ApiResponse.success("Low stock items retrieved", inventoryService.getLowStockItems(threshold)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update inventory record")
    public ResponseEntity<ApiResponse<InventoryDTO>> updateInventory(@PathVariable Long id,
                                                                      @Valid @RequestBody InventoryDTO dto) {
        return ResponseEntity.ok(ApiResponse.success("Inventory updated successfully", inventoryService.updateInventory(id, dto)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete inventory record")
    public ResponseEntity<ApiResponse<Void>> deleteInventory(@PathVariable Long id) {
        inventoryService.deleteInventory(id);
        return ResponseEntity.ok(ApiResponse.success("Inventory deleted successfully", null));
    }
}

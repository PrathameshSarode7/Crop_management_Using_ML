package com.ecommerce.inventoryservice.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryDTO {

    private Long id;

    @NotNull(message = "Item ID is required")
    private Long itemId;

    @NotNull(message = "Quantity is required")
    @Min(value = 0, message = "Quantity cannot be negative")
    private Integer quantity;

    @NotBlank(message = "Warehouse location is required")
    @Size(max = 100, message = "Warehouse location must not exceed 100 characters")
    private String warehouseLocation;

    private LocalDateTime lastUpdated;
}

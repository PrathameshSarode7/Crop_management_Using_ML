package com.ecommerce.inventoryservice.exception;

public class InventoryNotFoundException extends RuntimeException {
    public InventoryNotFoundException(String message) {
        super(message);
    }
    public InventoryNotFoundException(Long id) {
        super("Inventory record not found with id: " + id);
    }
}

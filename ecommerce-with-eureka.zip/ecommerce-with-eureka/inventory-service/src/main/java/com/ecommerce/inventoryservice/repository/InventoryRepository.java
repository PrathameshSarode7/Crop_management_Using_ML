package com.ecommerce.inventoryservice.repository;

import com.ecommerce.inventoryservice.model.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    List<Inventory> findByItemId(Long itemId);
    Optional<Inventory> findByItemIdAndWarehouseLocation(Long itemId, String warehouseLocation);
    List<Inventory> findByQuantityLessThan(Integer threshold);
}

package com.ecommerce.inventoryservice.service;

import com.ecommerce.inventoryservice.dto.InventoryDTO;
import java.util.List;

public interface InventoryService {
    InventoryDTO addInventory(InventoryDTO dto);
    InventoryDTO getInventoryById(Long id);
    List<InventoryDTO> getAllInventory();
    List<InventoryDTO> getInventoryByItemId(Long itemId);
    List<InventoryDTO> getLowStockItems(Integer threshold);
    InventoryDTO updateInventory(Long id, InventoryDTO dto);
    void deleteInventory(Long id);
}

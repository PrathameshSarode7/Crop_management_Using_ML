package com.ecommerce.inventoryservice.service;

import com.ecommerce.inventoryservice.dto.InventoryDTO;
import com.ecommerce.inventoryservice.exception.InventoryNotFoundException;
import com.ecommerce.inventoryservice.model.Inventory;
import com.ecommerce.inventoryservice.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository inventoryRepository;

    @Override
    public InventoryDTO addInventory(InventoryDTO dto) {
        log.info("Adding inventory for itemId: {}", dto.getItemId());
        Inventory inv = Inventory.builder()
                .itemId(dto.getItemId())
                .quantity(dto.getQuantity())
                .warehouseLocation(dto.getWarehouseLocation())
                .lastUpdated(LocalDateTime.now())
                .build();
        return toDTO(inventoryRepository.save(inv));
    }

    @Override
    @Transactional(readOnly = true)
    public InventoryDTO getInventoryById(Long id) {
        return toDTO(inventoryRepository.findById(id)
                .orElseThrow(() -> new InventoryNotFoundException(id)));
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryDTO> getAllInventory() {
        return inventoryRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryDTO> getInventoryByItemId(Long itemId) {
        return inventoryRepository.findByItemId(itemId).stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<InventoryDTO> getLowStockItems(Integer threshold) {
        return inventoryRepository.findByQuantityLessThan(threshold).stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    public InventoryDTO updateInventory(Long id, InventoryDTO dto) {
        log.info("Updating inventory id: {}", id);
        Inventory inv = inventoryRepository.findById(id)
                .orElseThrow(() -> new InventoryNotFoundException(id));
        inv.setItemId(dto.getItemId());
        inv.setQuantity(dto.getQuantity());
        inv.setWarehouseLocation(dto.getWarehouseLocation());
        inv.setLastUpdated(LocalDateTime.now());
        return toDTO(inventoryRepository.save(inv));
    }

    @Override
    public void deleteInventory(Long id) {
        log.info("Deleting inventory id: {}", id);
        if (!inventoryRepository.existsById(id)) {
            throw new InventoryNotFoundException(id);
        }
        inventoryRepository.deleteById(id);
    }

    private InventoryDTO toDTO(Inventory inv) {
        return InventoryDTO.builder()
                .id(inv.getId())
                .itemId(inv.getItemId())
                .quantity(inv.getQuantity())
                .warehouseLocation(inv.getWarehouseLocation())
                .lastUpdated(inv.getLastUpdated())
                .build();
    }
}

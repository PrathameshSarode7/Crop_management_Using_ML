package com.ecommerce.inventoryservice;

import com.ecommerce.inventoryservice.dto.InventoryDTO;
import com.ecommerce.inventoryservice.exception.InventoryNotFoundException;
import com.ecommerce.inventoryservice.model.Inventory;
import com.ecommerce.inventoryservice.repository.InventoryRepository;
import com.ecommerce.inventoryservice.service.InventoryServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InventoryServiceTest {

    @Mock
    private InventoryRepository inventoryRepository;

    @InjectMocks
    private InventoryServiceImpl inventoryService;

    private Inventory sampleInventory;
    private InventoryDTO sampleDTO;

    @BeforeEach
    void setUp() {
        sampleInventory = Inventory.builder()
                .id(1L).itemId(1005L).quantity(150)
                .warehouseLocation("A1-North").lastUpdated(LocalDateTime.now()).build();
        sampleDTO = InventoryDTO.builder()
                .itemId(1005L).quantity(150).warehouseLocation("A1-North").build();
    }

    @Test
    void addInventory_ShouldReturnSaved() {
        when(inventoryRepository.save(any())).thenReturn(sampleInventory);
        InventoryDTO result = inventoryService.addInventory(sampleDTO);
        assertThat(result.getItemId()).isEqualTo(1005L);
        assertThat(result.getQuantity()).isEqualTo(150);
    }

    @Test
    void getInventoryById_WhenExists_ShouldReturn() {
        when(inventoryRepository.findById(1L)).thenReturn(Optional.of(sampleInventory));
        InventoryDTO result = inventoryService.getInventoryById(1L);
        assertThat(result.getId()).isEqualTo(1L);
    }

    @Test
    void getInventoryById_WhenNotExists_ShouldThrow() {
        when(inventoryRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> inventoryService.getInventoryById(99L))
                .isInstanceOf(InventoryNotFoundException.class);
    }

    @Test
    void deleteInventory_WhenExists_ShouldDelete() {
        when(inventoryRepository.existsById(1L)).thenReturn(true);
        inventoryService.deleteInventory(1L);
        verify(inventoryRepository).deleteById(1L);
    }
}

package com.ecommerce.itemservice.service;

import com.ecommerce.itemservice.dto.ItemDTO;
import java.util.List;

public interface ItemService {
    ItemDTO createItem(ItemDTO itemDTO);
    ItemDTO getItemById(Long id);
    List<ItemDTO> getAllItems();
    List<ItemDTO> getItemsByCategory(String category);
    ItemDTO updateItem(Long id, ItemDTO itemDTO);
    void deleteItem(Long id);
}

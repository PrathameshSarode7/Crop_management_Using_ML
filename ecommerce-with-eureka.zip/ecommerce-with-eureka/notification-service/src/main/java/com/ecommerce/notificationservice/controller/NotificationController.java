package com.ecommerce.notificationservice.controller;

import com.ecommerce.notificationservice.dto.ApiResponse;
import com.ecommerce.notificationservice.dto.NotificationDTO;
import com.ecommerce.notificationservice.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@Tag(name = "Notification Service", description = "APIs for sending and managing notifications")
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping
    @Operation(summary = "Send a new notification")
    public ResponseEntity<ApiResponse<NotificationDTO>> sendNotification(@Valid @RequestBody NotificationDTO dto) {
        NotificationDTO created = notificationService.sendNotification(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Notification sent successfully", created));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get notification by ID")
    public ResponseEntity<ApiResponse<NotificationDTO>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Notification retrieved", notificationService.getNotificationById(id)));
    }

    @GetMapping
    @Operation(summary = "Get all notification logs")
    public ResponseEntity<ApiResponse<List<NotificationDTO>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Notifications retrieved", notificationService.getAllNotifications()));
    }

    @GetMapping("/event/{eventType}")
    @Operation(summary = "Get notifications by event type")
    public ResponseEntity<ApiResponse<List<NotificationDTO>>> getByEventType(@PathVariable String eventType) {
        return ResponseEntity.ok(ApiResponse.success("Notifications retrieved", notificationService.getByEventType(eventType)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update notification settings")
    public ResponseEntity<ApiResponse<NotificationDTO>> updateNotification(@PathVariable Long id,
                                                                            @Valid @RequestBody NotificationDTO dto) {
        return ResponseEntity.ok(ApiResponse.success("Notification updated", notificationService.updateNotification(id, dto)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Remove a notification entry")
    public ResponseEntity<ApiResponse<Void>> deleteNotification(@PathVariable Long id) {
        notificationService.deleteNotification(id);
        return ResponseEntity.ok(ApiResponse.success("Notification deleted", null));
    }
}

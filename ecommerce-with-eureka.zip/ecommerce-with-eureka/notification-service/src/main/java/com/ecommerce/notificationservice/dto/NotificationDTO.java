package com.ecommerce.notificationservice.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationDTO {

    private Long id;

    @NotBlank(message = "Event type is required")
    @Size(max = 100)
    private String eventType;

    @NotBlank(message = "Recipient is required")
    @Email(message = "Recipient must be a valid email")
    @Size(max = 150)
    private String recipient;

    @NotBlank(message = "Message is required")
    private String message;

    private LocalDateTime sentAt;
}

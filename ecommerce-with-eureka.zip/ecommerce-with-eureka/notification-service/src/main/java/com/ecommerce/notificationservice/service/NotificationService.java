package com.ecommerce.notificationservice.service;

import com.ecommerce.notificationservice.dto.NotificationDTO;
import java.util.List;

public interface NotificationService {
    NotificationDTO sendNotification(NotificationDTO dto);
    NotificationDTO getNotificationById(Long id);
    List<NotificationDTO> getAllNotifications();
    List<NotificationDTO> getByEventType(String eventType);
    NotificationDTO updateNotification(Long id, NotificationDTO dto);
    void deleteNotification(Long id);
}

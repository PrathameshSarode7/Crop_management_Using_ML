package com.ecommerce.notificationservice.service;

import com.ecommerce.notificationservice.dto.NotificationDTO;
import com.ecommerce.notificationservice.exception.NotificationNotFoundException;
import com.ecommerce.notificationservice.model.Notification;
import com.ecommerce.notificationservice.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;

    @Override
    public NotificationDTO sendNotification(NotificationDTO dto) {
        log.info("Sending notification: eventType={}, recipient={}", dto.getEventType(), dto.getRecipient());
        Notification notification = Notification.builder()
                .eventType(dto.getEventType())
                .recipient(dto.getRecipient())
                .message(dto.getMessage())
                .sentAt(LocalDateTime.now())
                .build();
        return toDTO(notificationRepository.save(notification));
    }

    @Override
    @Transactional(readOnly = true)
    public NotificationDTO getNotificationById(Long id) {
        return toDTO(notificationRepository.findById(id)
                .orElseThrow(() -> new NotificationNotFoundException(id)));
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationDTO> getAllNotifications() {
        return notificationRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationDTO> getByEventType(String eventType) {
        return notificationRepository.findByEventType(eventType).stream().map(this::toDTO).collect(Collectors.toList());
    }

    @Override
    public NotificationDTO updateNotification(Long id, NotificationDTO dto) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new NotificationNotFoundException(id));
        notification.setEventType(dto.getEventType());
        notification.setRecipient(dto.getRecipient());
        notification.setMessage(dto.getMessage());
        return toDTO(notificationRepository.save(notification));
    }

    @Override
    public void deleteNotification(Long id) {
        if (!notificationRepository.existsById(id)) {
            throw new NotificationNotFoundException(id);
        }
        notificationRepository.deleteById(id);
        log.info("Notification deleted: {}", id);
    }

    private NotificationDTO toDTO(Notification n) {
        return NotificationDTO.builder()
                .id(n.getId())
                .eventType(n.getEventType())
                .recipient(n.getRecipient())
                .message(n.getMessage())
                .sentAt(n.getSentAt())
                .build();
    }
}

package com.ecommerce.notificationservice;

import com.ecommerce.notificationservice.dto.NotificationDTO;
import com.ecommerce.notificationservice.exception.NotificationNotFoundException;
import com.ecommerce.notificationservice.model.Notification;
import com.ecommerce.notificationservice.repository.NotificationRepository;
import com.ecommerce.notificationservice.service.NotificationServiceImpl;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private NotificationServiceImpl notificationService;

    private Notification sample;
    private NotificationDTO sampleDTO;

    @BeforeEach
    void setUp() {
        sample = Notification.builder()
                .id(1L).eventType("LowStock")
                .recipient("manager@company.com")
                .message("Stock dropped below threshold")
                .sentAt(LocalDateTime.now()).build();
        sampleDTO = NotificationDTO.builder()
                .eventType("LowStock").recipient("manager@company.com")
                .message("Stock dropped below threshold").build();
    }

    @Test
    void sendNotification_ShouldReturnSaved() {
        when(notificationRepository.save(any())).thenReturn(sample);
        NotificationDTO result = notificationService.sendNotification(sampleDTO);
        assertThat(result.getEventType()).isEqualTo("LowStock");
    }

    @Test
    void getById_WhenNotExists_ShouldThrow() {
        when(notificationRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> notificationService.getNotificationById(99L))
                .isInstanceOf(NotificationNotFoundException.class);
    }

    @Test
    void deleteNotification_ShouldDelete() {
        when(notificationRepository.existsById(1L)).thenReturn(true);
        notificationService.deleteNotification(1L);
        verify(notificationRepository).deleteById(1L);
    }
}
